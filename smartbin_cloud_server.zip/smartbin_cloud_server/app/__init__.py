"""SmartBin cloud server package."""
