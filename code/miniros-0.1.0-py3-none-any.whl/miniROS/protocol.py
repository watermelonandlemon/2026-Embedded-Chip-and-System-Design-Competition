"""miniROS 内部通信协议。"""

from __future__ import annotations

import json
import re
from typing import Any, Dict

MAX_MESSAGE_BYTES = 4 * 1024 * 1024
_TOPIC_PATTERN = re.compile(r"^/[A-Za-z0-9_./-]+$")


def normalize_topic(topic: str) -> str:
    """校验并规范化话题名称。"""
    if not isinstance(topic, str):
        raise TypeError("topic 必须是字符串")
    topic = topic.strip()
    if not topic:
        raise ValueError("topic 不能为空")
    if not topic.startswith("/"):
        topic = "/" + topic
    if len(topic) > 256:
        raise ValueError("topic 长度不能超过 256 个字符")
    if not _TOPIC_PATTERN.fullmatch(topic):
        raise ValueError(
            "topic 只能包含字母、数字、下划线、点、斜杠和连字符，例如 /vision/result"
        )
    return topic


def encode_message(message: Dict[str, Any]) -> bytes:
    """将字典编码为一行 UTF-8 JSON。"""
    raw = json.dumps(
        message,
        ensure_ascii=False,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    if len(raw) > MAX_MESSAGE_BYTES:
        raise ValueError(f"消息超过最大限制 {MAX_MESSAGE_BYTES} 字节")
    return raw + b"\n"


def decode_message(line: bytes) -> Dict[str, Any]:
    """将一行 UTF-8 JSON 解码为字典。"""
    if len(line) > MAX_MESSAGE_BYTES + 1:
        raise ValueError("收到的消息过大")
    value = json.loads(line.decode("utf-8"))
    if not isinstance(value, dict):
        raise ValueError("协议消息必须是 JSON 对象")
    return value
