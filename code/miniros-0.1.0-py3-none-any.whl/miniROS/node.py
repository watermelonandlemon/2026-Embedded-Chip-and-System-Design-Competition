"""miniROS 节点客户端。"""

from __future__ import annotations

import itertools
import logging
import socket
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Callable, Dict, List, Optional, Set

from .protocol import MAX_MESSAGE_BYTES, decode_message, encode_message, normalize_topic

LOGGER = logging.getLogger("miniROS.node")
Callback = Callable[[Any], None]


class MiniROSNode:
    """
    miniROS 节点。

    一个节点可以注册发布者、注册订阅者，并通过中心 Broker 与其他 Python 程序通信。
    """

    def __init__(
        self,
        name: str,
        host: str = "127.0.0.1",
        port: int = 8765,
        *,
        auto_reconnect: bool = True,
        reconnect_interval: float = 1.0,
        connect_timeout: float = 5.0,
        callback_workers: int = 4,
    ) -> None:
        if not isinstance(name, str) or not name.strip():
            raise ValueError("节点名称不能为空")
        if callback_workers < 1:
            raise ValueError("callback_workers 必须大于等于 1")

        self.name = name.strip()
        self.host = host
        self.port = int(port)
        self.auto_reconnect = auto_reconnect
        self.reconnect_interval = max(0.1, float(reconnect_interval))
        self.connect_timeout = float(connect_timeout)

        self._publishers: Set[str] = set()
        self._callbacks: Dict[str, List[Callback]] = {}
        self._registration_lock = threading.RLock()

        self._socket: Optional[socket.socket] = None
        self._socket_lock = threading.RLock()
        self._send_lock = threading.Lock()

        self._stop_event = threading.Event()
        self._connected_event = threading.Event()
        self._manager_thread: Optional[threading.Thread] = None
        self._executor = ThreadPoolExecutor(
            max_workers=callback_workers,
            thread_name_prefix=f"miniROS-{self.name}-callback",
        )
        self._sequence = itertools.count(1)
        self._last_error: Optional[BaseException] = None

        self.connect(timeout=self.connect_timeout)

    @property
    def is_connected(self) -> bool:
        return self._connected_event.is_set()

    @property
    def last_error(self) -> Optional[BaseException]:
        return self._last_error

    def connect(self, timeout: Optional[float] = None) -> None:
        """连接 Broker；已连接时不会重复创建连接。"""
        if self._stop_event.is_set():
            raise RuntimeError("节点已经关闭，不能重新连接")
        if self._manager_thread is None or not self._manager_thread.is_alive():
            self._manager_thread = threading.Thread(
                target=self._connection_loop,
                name=f"miniROS-{self.name}-connection",
                daemon=True,
            )
            self._manager_thread.start()

        wait_timeout = self.connect_timeout if timeout is None else timeout
        if not self._connected_event.wait(wait_timeout):
            detail = f"，最后错误：{self._last_error}" if self._last_error else ""
            raise TimeoutError(
                f"无法在 {wait_timeout:.1f}s 内连接 miniROS Broker "
                f"{self.host}:{self.port}{detail}"
            )

    def wait_for_connection(self, timeout: Optional[float] = None) -> bool:
        """等待连接恢复，返回是否成功连接。"""
        return self._connected_event.wait(timeout)

    def register_publisher(self, topic: str) -> str:
        """注册一个可发布的话题。"""
        topic = normalize_topic(topic)
        with self._registration_lock:
            is_new = topic not in self._publishers
            self._publishers.add(topic)
        if is_new and self.is_connected:
            self._send({"op": "advertise", "topic": topic})
        return topic

    advertise = register_publisher

    def register_subscriber(self, topic: str, callback: Callback) -> str:
        """注册话题监听函数。收到消息时调用 callback(payload)。"""
        if not callable(callback):
            raise TypeError("callback 必须是可调用对象")
        topic = normalize_topic(topic)
        with self._registration_lock:
            callbacks = self._callbacks.setdefault(topic, [])
            first_subscription = not callbacks
            if callback not in callbacks:
                callbacks.append(callback)
        if first_subscription and self.is_connected:
            self._send({"op": "subscribe", "topic": topic})
        return topic

    subscribe = register_subscriber

    def unregister_subscriber(self, topic: str, callback: Optional[Callback] = None) -> None:
        """取消一个回调，或取消整个话题的监听。"""
        topic = normalize_topic(topic)
        should_unsubscribe = False
        with self._registration_lock:
            callbacks = self._callbacks.get(topic)
            if callbacks is None:
                return
            if callback is None:
                self._callbacks.pop(topic, None)
                should_unsubscribe = True
            else:
                try:
                    callbacks.remove(callback)
                except ValueError:
                    return
                if not callbacks:
                    self._callbacks.pop(topic, None)
                    should_unsubscribe = True
        if should_unsubscribe and self.is_connected:
            self._send({"op": "unsubscribe", "topic": topic})

    unsubscribe = unregister_subscriber

    def publish(self, topic: str, payload: Any) -> int:
        """
        发布消息。

        payload 必须能被 JSON 序列化。返回本地消息序号。
        首次发布未注册的话题时会自动注册。
        """
        topic = normalize_topic(topic)
        self.register_publisher(topic)
        sequence = next(self._sequence)
        self._send(
            {
                "op": "publish",
                "topic": topic,
                "sequence": sequence,
                "timestamp": time.time(),
                "payload": payload,
            }
        )
        return sequence

    def ping(self) -> None:
        """向 Broker 发送一次心跳。"""
        self._send({"op": "ping", "timestamp": time.time()})

    def spin(self) -> None:
        """持续保持节点运行，直到 Ctrl+C。"""
        try:
            while not self._stop_event.wait(0.5):
                pass
        except KeyboardInterrupt:
            pass
        finally:
            self.close()

    def close(self) -> None:
        """关闭节点、网络连接和回调线程池。"""
        if self._stop_event.is_set():
            return
        self._stop_event.set()
        self._connected_event.clear()

        with self._socket_lock:
            sock = self._socket
            self._socket = None
        if sock is not None:
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            try:
                sock.close()
            except OSError:
                pass

        if self._manager_thread is not None and self._manager_thread is not threading.current_thread():
            self._manager_thread.join(timeout=2.0)
        self._executor.shutdown(wait=False, cancel_futures=True)

    shutdown = close

    def __enter__(self) -> "MiniROSNode":
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        self.close()

    def _connection_loop(self) -> None:
        while not self._stop_event.is_set():
            sock: Optional[socket.socket] = None
            try:
                sock = socket.create_connection(
                    (self.host, self.port),
                    timeout=self.connect_timeout,
                )
                sock.settimeout(None)
                try:
                    sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                except OSError:
                    pass

                with self._socket_lock:
                    self._socket = sock

                self._send_direct(sock, {"op": "hello", "node": self.name})
                self._connected_event.set()
                self._last_error = None
                self._replay_registrations()
                LOGGER.info("节点 %s 已连接 Broker %s:%d", self.name, self.host, self.port)

                reader = sock.makefile("rb")
                try:
                    while not self._stop_event.is_set():
                        line = reader.readline(MAX_MESSAGE_BYTES + 2)
                        if not line:
                            raise ConnectionError("Broker 已断开连接")
                        if len(line) > MAX_MESSAGE_BYTES + 1 or not line.endswith(b"\n"):
                            raise ConnectionError("收到过大或不完整的协议消息")
                        packet = decode_message(line)
                        self._handle_packet(packet)
                finally:
                    reader.close()
            except (OSError, ConnectionError, ValueError) as exc:
                self._last_error = exc
                if not self._stop_event.is_set():
                    LOGGER.warning("节点 %s 连接异常：%s", self.name, exc)
            finally:
                self._connected_event.clear()
                with self._socket_lock:
                    if self._socket is sock:
                        self._socket = None
                if sock is not None:
                    try:
                        sock.close()
                    except OSError:
                        pass

            if not self.auto_reconnect or self._stop_event.wait(self.reconnect_interval):
                break

    def _replay_registrations(self) -> None:
        with self._registration_lock:
            publishers = tuple(self._publishers)
            subscribers = tuple(topic for topic, callbacks in self._callbacks.items() if callbacks)
        for topic in publishers:
            self._send({"op": "advertise", "topic": topic})
        for topic in subscribers:
            self._send({"op": "subscribe", "topic": topic})

    def _send_direct(self, sock: socket.socket, packet: dict) -> None:
        data = encode_message(packet)
        with self._send_lock:
            sock.sendall(data)

    def _send(self, packet: dict) -> None:
        if not self._connected_event.wait(self.connect_timeout):
            raise ConnectionError(
                f"节点未连接 Broker {self.host}:{self.port}；最后错误：{self._last_error}"
            )
        with self._socket_lock:
            sock = self._socket
        if sock is None:
            raise ConnectionError("节点连接正在恢复，请稍后重试")
        try:
            self._send_direct(sock, packet)
        except OSError as exc:
            self._connected_event.clear()
            self._last_error = exc
            raise ConnectionError("消息发送失败，连接可能已经断开") from exc

    def _handle_packet(self, packet: dict) -> None:
        op = packet.get("op")
        if op == "message":
            topic = normalize_topic(packet.get("topic", ""))
            payload = packet.get("payload")
            with self._registration_lock:
                callbacks = tuple(self._callbacks.get(topic, ()))
            for callback in callbacks:
                self._executor.submit(self._invoke_callback, callback, topic, payload)
        elif op == "error":
            LOGGER.error("Broker 返回错误：%s", packet.get("message", "未知错误"))
        elif op in {"hello_ack", "ack", "pong"}:
            return
        else:
            LOGGER.debug("忽略未知 Broker 消息：%r", packet)

    @staticmethod
    def _invoke_callback(callback: Callback, topic: str, payload: Any) -> None:
        try:
            callback(payload)
        except Exception:
            LOGGER.exception("话题 %s 的回调函数执行失败", topic)
