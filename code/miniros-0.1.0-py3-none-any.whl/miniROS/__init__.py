"""miniROS：面向 Python 多进程/多设备程序的轻量级话题通信库。"""

from .node import MiniROSNode

Node = MiniROSNode
MiniROS = MiniROSNode

__all__ = ["MiniROSNode", "Node", "MiniROS"]
__version__ = "0.1.0"
