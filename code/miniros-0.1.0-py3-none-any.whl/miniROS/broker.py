"""miniROS 中心消息代理（Broker）。"""

from __future__ import annotations

import argparse
import logging
import socket
import socketserver
import threading
import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import DefaultDict, Dict, Optional, Set

from .protocol import MAX_MESSAGE_BYTES, decode_message, encode_message, normalize_topic

LOGGER = logging.getLogger("miniROS.broker")


@dataclass
class ClientInfo:
    node_name: str = "unknown"
    publishers: Set[str] = field(default_factory=set)
    subscribers: Set[str] = field(default_factory=set)


class BrokerState:
    """保存在线节点与话题订阅关系。"""

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self.clients: Dict["MiniROSRequestHandler", ClientInfo] = {}
        self.subscribers: DefaultDict[str, Set["MiniROSRequestHandler"]] = defaultdict(set)

    def register_client(self, handler: "MiniROSRequestHandler", node_name: str) -> None:
        with self._lock:
            self.clients[handler] = ClientInfo(node_name=node_name)

    def unregister_client(self, handler: "MiniROSRequestHandler") -> None:
        with self._lock:
            info = self.clients.pop(handler, None)
            if info is None:
                return
            for topic in info.subscribers:
                handlers = self.subscribers.get(topic)
                if handlers is not None:
                    handlers.discard(handler)
                    if not handlers:
                        self.subscribers.pop(topic, None)

    def advertise(self, handler: "MiniROSRequestHandler", topic: str) -> None:
        with self._lock:
            self.clients[handler].publishers.add(topic)

    def subscribe(self, handler: "MiniROSRequestHandler", topic: str) -> None:
        with self._lock:
            self.clients[handler].subscribers.add(topic)
            self.subscribers[topic].add(handler)

    def unsubscribe(self, handler: "MiniROSRequestHandler", topic: str) -> None:
        with self._lock:
            info = self.clients.get(handler)
            if info is not None:
                info.subscribers.discard(topic)
            handlers = self.subscribers.get(topic)
            if handlers is not None:
                handlers.discard(handler)
                if not handlers:
                    self.subscribers.pop(topic, None)

    def publish(self, handler: "MiniROSRequestHandler", packet: dict) -> int:
        topic = normalize_topic(packet.get("topic", ""))
        with self._lock:
            info = self.clients[handler]
            info.publishers.add(topic)
            targets = tuple(self.subscribers.get(topic, ()))
            source = info.node_name

        outbound = {
            "op": "message",
            "topic": topic,
            "source": source,
            "sequence": packet.get("sequence"),
            "timestamp": packet.get("timestamp", time.time()),
            "payload": packet.get("payload"),
        }

        delivered = 0
        for target in targets:
            try:
                target.send_packet(outbound)
                delivered += 1
            except OSError:
                self.unregister_client(target)
        return delivered


class MiniROSRequestHandler(socketserver.StreamRequestHandler):
    """处理一个 miniROS 节点连接。"""

    server: "MiniROSTCPServer"

    def setup(self) -> None:
        super().setup()
        self._send_lock = threading.Lock()
        self._registered = False
        try:
            self.request.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        except OSError:
            pass

    def send_packet(self, packet: dict) -> None:
        data = encode_message(packet)
        with self._send_lock:
            self.request.sendall(data)

    def _send_error(self, message: str) -> None:
        try:
            self.send_packet({"op": "error", "message": message})
        except OSError:
            pass

    def handle(self) -> None:
        peer = f"{self.client_address[0]}:{self.client_address[1]}"
        LOGGER.info("节点连接：%s", peer)
        try:
            while True:
                line = self.rfile.readline(MAX_MESSAGE_BYTES + 2)
                if not line:
                    break
                if len(line) > MAX_MESSAGE_BYTES + 1 or not line.endswith(b"\n"):
                    self._send_error("消息过大或缺少换行结束符")
                    break
                try:
                    packet = decode_message(line)
                    self._process_packet(packet)
                except (ValueError, TypeError, KeyError) as exc:
                    self._send_error(str(exc))
        except (ConnectionError, OSError):
            pass
        finally:
            self.server.state.unregister_client(self)
            LOGGER.info("节点断开：%s", peer)

    def _process_packet(self, packet: dict) -> None:
        op = packet.get("op")

        if op == "hello":
            node_name = packet.get("node")
            if not isinstance(node_name, str) or not node_name.strip():
                raise ValueError("node 名称不能为空")
            self.server.state.register_client(self, node_name.strip())
            self._registered = True
            self.send_packet({"op": "hello_ack", "node": node_name.strip()})
            return

        if not self._registered:
            raise ValueError("必须先发送 hello 注册节点")

        if op == "advertise":
            topic = normalize_topic(packet.get("topic", ""))
            self.server.state.advertise(self, topic)
            self.send_packet({"op": "ack", "action": "advertise", "topic": topic})
        elif op == "subscribe":
            topic = normalize_topic(packet.get("topic", ""))
            self.server.state.subscribe(self, topic)
            self.send_packet({"op": "ack", "action": "subscribe", "topic": topic})
        elif op == "unsubscribe":
            topic = normalize_topic(packet.get("topic", ""))
            self.server.state.unsubscribe(self, topic)
            self.send_packet({"op": "ack", "action": "unsubscribe", "topic": topic})
        elif op == "publish":
            self.server.state.publish(self, packet)
        elif op == "ping":
            self.send_packet({"op": "pong", "timestamp": time.time()})
        elif op == "disconnect":
            raise ConnectionAbortedError("客户端主动断开")
        else:
            raise ValueError(f"未知操作：{op!r}")


class MiniROSTCPServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True

    def __init__(self, server_address: tuple[str, int]) -> None:
        self.state = BrokerState()
        super().__init__(server_address, MiniROSRequestHandler)


def run_broker(host: str = "0.0.0.0", port: int = 8765) -> None:
    """启动并持续运行中心消息代理。"""
    with MiniROSTCPServer((host, port)) as server:
        LOGGER.info("miniROS Broker 已启动：%s:%d", host, port)
        try:
            server.serve_forever(poll_interval=0.2)
        except KeyboardInterrupt:
            LOGGER.info("正在停止 miniROS Broker")
        finally:
            server.shutdown()


def main() -> None:
    parser = argparse.ArgumentParser(description="miniROS 轻量级话题通信代理")
    parser.add_argument("--host", default="0.0.0.0", help="监听地址，默认 0.0.0.0")
    parser.add_argument("--port", type=int, default=8765, help="监听端口，默认 8765")
    parser.add_argument("--log-level", default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    args = parser.parse_args()

    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    run_broker(args.host, args.port)


if __name__ == "__main__":
    main()
