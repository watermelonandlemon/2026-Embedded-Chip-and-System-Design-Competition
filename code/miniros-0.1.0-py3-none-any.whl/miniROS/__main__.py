"""允许执行 python -m miniROS 启动 Broker。"""

from .broker import main

if __name__ == "__main__":
    main()
